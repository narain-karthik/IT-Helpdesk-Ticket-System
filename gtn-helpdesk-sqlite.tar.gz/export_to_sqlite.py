#!/usr/bin/env python3
"""
Export GTN Engineering IT Helpdesk to SQLite
This script creates a complete SQLite database with all the schema and sample data
"""

import os
import sqlite3
from datetime import datetime
from werkzeug.security import generate_password_hash

def create_sqlite_database():
    """Create SQLite database with complete schema and sample data"""
    
    # Remove existing database if it exists
    if os.path.exists('gtn_helpdesk.db'):
        os.remove('gtn_helpdesk.db')
    
    # Connect to SQLite database
    conn = sqlite3.connect('gtn_helpdesk.db')
    cursor = conn.cursor()
    
    # Create Users table
    cursor.execute('''
        CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username VARCHAR(80) UNIQUE NOT NULL,
            email VARCHAR(120) UNIQUE NOT NULL,
            password_hash VARCHAR(256) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            department VARCHAR(100),
            role VARCHAR(20) DEFAULT 'user',
            is_admin BOOLEAN DEFAULT 0,
            ip_address VARCHAR(45),
            system_name VARCHAR(100),
            profile_image VARCHAR(200),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    # Create Tickets table
    cursor.execute('''
        CREATE TABLE tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title VARCHAR(200) NOT NULL,
            description TEXT NOT NULL,
            category VARCHAR(50) NOT NULL,
            priority VARCHAR(20) NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'Open',
            user_name VARCHAR(100) NOT NULL,
            user_ip_address VARCHAR(45),
            user_system_name VARCHAR(100),
            user_id INTEGER NOT NULL,
            assigned_to INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            resolved_at DATETIME,
            FOREIGN KEY (user_id) REFERENCES users (id),
            FOREIGN KEY (assigned_to) REFERENCES users (id)
        )
    ''')
    
    # Create Ticket Comments table
    cursor.execute('''
        CREATE TABLE ticket_comments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ticket_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            comment TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (ticket_id) REFERENCES tickets (id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Insert sample users
    users_data = [
        # Super Admin
        ('superadmin', 'superadmin@gtnengineering.com', generate_password_hash('super123'), 
         'Super', 'Administrator', 'IT', 'super_admin', 1),
        
        # Hardware Admins
        ('yuvaraj', 'yuvaraj@gtnengineering.com', generate_password_hash('admin123'),
         'Yuvaraj', 'Admin', 'IT Hardware', 'admin', 1),
        ('jayachandran', 'jayachandran@gtnengineering.com', generate_password_hash('admin123'),
         'Jayachandran', 'Admin', 'IT Hardware', 'admin', 1),
        ('narainkarthik', 'narainkarthik@gtnengineering.com', generate_password_hash('admin123'),
         'Narain', 'Karthik', 'IT Hardware', 'admin', 1),
         
        # Software Admins
        ('sathish', 'sathish@gtnengineering.com', generate_password_hash('admin123'),
         'Sathish', 'SAP Admin', 'IT Software', 'admin', 1),
        ('lakshmiprabha', 'lakshmiprabha@gtnengineering.com', generate_password_hash('admin123'),
         'Lakshmi', 'Prabha', 'IT Software', 'admin', 1),
         
        # Test User
        ('testuser', 'user@gtnengineering.com', generate_password_hash('test123'),
         'Test', 'User', 'Engineering', 'user', 0),
    ]
    
    cursor.executemany('''
        INSERT INTO users (username, email, password_hash, first_name, last_name, 
                          department, role, is_admin)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ''', users_data)
    
    # Insert sample tickets
    sample_tickets = [
        ('Laptop not starting', 'My laptop is not turning on after the latest update. The power button shows no response.', 
         'Hardware', 'High', 'Open', 'Test User', '192.168.1.100', 'DESKTOP-ABC123', 7),
        ('SAP login issues', 'Unable to login to SAP system. Getting authentication error.', 
         'Software', 'Medium', 'Open', 'Test User', '192.168.1.100', 'DESKTOP-ABC123', 7),
        ('Network connectivity problem', 'Internet is very slow in our department.', 
         'Network', 'Low', 'Open', 'Test User', '192.168.1.100', 'DESKTOP-ABC123', 7),
    ]
    
    cursor.executemany('''
        INSERT INTO tickets (title, description, category, priority, status, 
                           user_name, user_ip_address, user_system_name, user_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    ''', sample_tickets)
    
    # Commit changes
    conn.commit()
    
    # Display summary
    cursor.execute("SELECT COUNT(*) FROM users")
    user_count = cursor.fetchone()[0]
    
    cursor.execute("SELECT COUNT(*) FROM tickets")
    ticket_count = cursor.fetchone()[0]
    
    print(f"✓ SQLite database 'gtn_helpdesk.db' created successfully!")
    print(f"✓ {user_count} users created")
    print(f"✓ {ticket_count} sample tickets created")
    print("\nUser Accounts:")
    print("Super Admin: superadmin / super123")
    print("Hardware Admins: yuvaraj, jayachandran, narainkarthik / admin123")
    print("Software Admins: sathish, lakshmiprabha / admin123")
    print("Test User: testuser / test123")
    
    conn.close()

if __name__ == "__main__":
    create_sqlite_database()